# Lab 1 — What Is In It? SBOM, VEX, SLSA

**16 minutes · hands-on**

Before you fix anything, you need to be able to describe what is wrong. This lab is
the vocabulary, and you apply all of it to the image the agent built.

---

## SBOM — what is in it

A Software Bill of Materials is an inventory: every package, version, licence and
supplier in the image.

1. Generate one in SPDX format:

    ```bash terminal-id=build
    docker scout sbom --format spdx --output baseline.spdx.json catalog-service:baseline
    ```

2. Count what you are shipping:

    ```bash terminal-id=build
    jq '.packages | length' baseline.spdx.json
    ```

3. Look at what they actually are:

    ```bash terminal-id=build
    jq -r '.packages[].name' baseline.spdx.json | sort | head -30
    ```

    Scroll it. Most of these you did not choose, did not install, and cannot name.

4. Now ask a question only an SBOM can answer — the one you get at 2am when a new CVE
   drops:

    ```bash terminal-id=build
    jq -r '.packages[] | select(.name | test("openssl|zlib|libxml")) | "\(.name) \(.versionInfo)"' baseline.spdx.json
    ```

> [!IMPORTANT]
> **Attested or indexed?** Docker Scout will index an image and construct an SBOM if
> the image does not ship one. That is a reconstruction — an educated guess from the
> filesystem.
>
> An SBOM *attestation* is a signed statement from whoever built the image: *this is
> what I put in it*. One is evidence. The other is inference. Which you have matters
> when an auditor asks.

---

## VEX — which findings matter

1. Look at the unfiltered list:

    ```bash terminal-id=build
    docker scout cves catalog-service:baseline --org $$org$$ --only-severity critical,high
    ```

2. Pick any finding and ask three questions about it:

    - Is that package reachable from the catalog's code path?
    - Is the vulnerable function ever called?
    - Would exploiting it need access an attacker would not already have?

For most of this list the honest answer is *no, no, and yes*. Your pipeline is still
red, and somebody still has a ticket.

`catalog-service:baseline` carries no exploitability data, because nobody produced
any. A hardened image does:

3. Pull a real VEX document and read one statement:

    ```bash terminal-id=build
    docker scout attest get $$dhiPrefix$$node:24-debian13 \
        --predicate-type https://openvex.dev/ns/v0.2.0 | jq '.statements[0]'
    ```

4. Read the fields:

    | Field | Meaning |
    |-------|---------|
    | `vulnerability` | Which CVE |
    | `products` | Which artifact, **by digest** |
    | `status` | `not_affected`, `affected`, `fixed`, `under_investigation` |
    | `justification` | *Why*, as a machine-readable enum |

That `justification` field is the whole point. It is a triage decision, made once by
someone who knew the answer, travelling with the artifact so nobody repeats the work.

> "Your image has 200 CVEs" and "190 not affected, 10 fixed" describe the same image.
> One sends four engineers into a triage meeting. The other is a decision somebody
> already made and signed.

---

## SLSA — where did it come from

SLSA defines build integrity levels. You only need to remember what Level 3 buys you.

| Level | Meaning |
|-------|---------|
| L0 | No guarantees |
| L1 | Provenance exists — build metadata documented |
| L2 | Hosted build with signed provenance |
| **L3** | **Hardened, non-falsifiable provenance — hardened images ship this** |

1. Read your own provenance first. The agent's build recorded some:

    ```bash terminal-id=build
    docker buildx imagetools inspect catalog-service:baseline --format '{{json .Provenance}}' | jq '.SLSA.builder'
    ```

2. Now read provenance you did not produce:

    ```bash terminal-id=build
    docker scout attest get $$dhiPrefix$$node:24-debian13 \
        --predicate-type https://slsa.dev/provenance/v0.2 \
        --verify
    ```

Trace it to a source repository and commit. You can go and read the code that produced
the image you are about to run in production.

---

## Signatures — can you verify it

An attestation is only worth the signature on it. Notice the `--verify` flag you just
used: that is the difference between a claim and evidence.

Run the same command without it and compare:

```bash terminal-id=build
docker scout attest get $$dhiPrefix$$node:24-debian13 \
    --predicate-type https://openvex.dev/ns/v0.2.0 | head -5
```

Both return a document. Only one of them proves who wrote it.

You will sign your own images in Lab 3.

---

## Checkpoint

- [ ] You know how many packages are in the agent's image
- [ ] You have queried the SBOM for a specific package version
- [ ] You have read a VEX statement, including its justification
- [ ] You have traced a hardened image to its source commit
- [ ] You can say what `--verify` changes

## What you should be thinking

You now have four measurements of the agent's image: package count, severity counts,
whether any exploitability assessment exists, and whether you can prove where it came
from.

For the last two the answer is *none* and *no*.

Hold on to those numbers. In Lab 2 every one of them changes, and because you did this
lab you will understand exactly why.

## Go deeper

If you finish early:

1. Generate a CycloneDX SBOM and compare the structure with SPDX:

    ```bash terminal-id=build
    docker scout sbom --format cyclonedx --output baseline.cdx.json catalog-service:baseline
    ```

2. Search the SBOM for copyleft licences — most teams have never looked:

    ```bash terminal-id=build
    jq -r '.packages[] | "\(.licenseConcluded)"' baseline.spdx.json | sort | uniq -c | sort -rn | head
    ```

3. Diff the package lists of two base images and find where the bulk goes.
